﻿using System.Windows.Forms;

namespace BulkPDF
{
    public partial class Licenses : Form
    {
        public Licenses()
        {
            InitializeComponent();
        }
    }
}